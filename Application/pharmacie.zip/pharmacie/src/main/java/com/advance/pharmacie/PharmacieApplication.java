package com.advance.pharmacie;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PharmacieApplication {

	public static void main(String[] args) {
		SpringApplication.run(PharmacieApplication.class, args);
	}

}
